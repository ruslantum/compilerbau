struct foo {
	int bar ,
        double baz
} ;

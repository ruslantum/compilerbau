int main() {
	if (345 % 23 < 1) for (a::b::c<int>::q apa; 0 > apa; apa += bepa % 3) {}
}

inline (cout << 5) bar () {}

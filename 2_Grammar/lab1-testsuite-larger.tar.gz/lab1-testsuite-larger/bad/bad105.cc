int typedef x;

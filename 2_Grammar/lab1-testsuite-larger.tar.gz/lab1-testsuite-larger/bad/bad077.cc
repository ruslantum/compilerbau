typedef (2+3) foo;

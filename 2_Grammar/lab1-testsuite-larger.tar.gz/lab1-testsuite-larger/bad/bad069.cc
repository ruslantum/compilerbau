struct foo x = 1;

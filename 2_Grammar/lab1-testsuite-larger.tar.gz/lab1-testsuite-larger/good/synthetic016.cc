int main() {
	if (banana2() == banana2()) while (!34) do x++; while (main());
}

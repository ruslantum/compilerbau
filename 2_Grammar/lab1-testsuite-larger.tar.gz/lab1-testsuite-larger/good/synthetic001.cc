typedef a::b::c<d>::q foo;

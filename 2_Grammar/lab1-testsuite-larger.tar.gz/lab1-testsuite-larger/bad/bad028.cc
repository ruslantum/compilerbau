struct bar {
	int baz;
        double foo;
}

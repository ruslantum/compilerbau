typedef foo;

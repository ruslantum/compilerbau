int foo(&int) {
	return x;
}

a::b::c<a::b::c<std::string>::q>::q xxx = "fpp!";

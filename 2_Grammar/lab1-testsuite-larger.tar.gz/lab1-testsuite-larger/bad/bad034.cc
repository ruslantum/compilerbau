int foo() {
	for (int i = 0; i < 5) { }
	return x;
}

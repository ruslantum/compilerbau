# Compiler construction exercise 4 - Code Generator
Definition of a code generator for a C++ subset defined in ../CPP.cf
Textual description available at http://www1.digitalgrammars.com/ipl-book/assignments/assignment3/assignment3.html and http://www1.digitalgrammars.com/ipl-book/assignments/assignment4/assignment4.html

# Authors
* Ruslan Tumarkin
* Benno Lauther


# Instructions

* `cd src/`
* `make`
* execute `./ccpp <path to file>`

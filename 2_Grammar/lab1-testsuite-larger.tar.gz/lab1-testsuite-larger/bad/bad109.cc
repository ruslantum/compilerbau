int main () {
	typedef x;
}

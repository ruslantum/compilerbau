int main () {
	int ia = 1;
	int ib = 2;
	int ic = 2;

	if (ia > ib) {
		return 1;
	} else {
		return 0;
	}
	if (ia < ib) {
		return 1;
	} else {
		return 0;
	}
	if (ia >= ib) {
		return 1;
	} else {
		return 0;
	}
	if (ia <= ib) {
		return 1;
	} else {
		return 0;
	}

	return 0;
}

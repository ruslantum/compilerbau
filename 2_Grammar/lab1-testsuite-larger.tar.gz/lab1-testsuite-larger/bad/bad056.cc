struct foo {
	int bar ,
} ;

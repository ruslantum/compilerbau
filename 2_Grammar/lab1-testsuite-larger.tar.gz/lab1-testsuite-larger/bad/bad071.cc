struct int x = 1;

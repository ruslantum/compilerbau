inline int f();

int main() {
	1;
	1.0;
	"foo";
	"foo" "Bar";
	"foo " "bar" "bazz";
	a::b::c<int>::qx;	
}

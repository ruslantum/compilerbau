struct {
	foo;
} ;

int main() {
	inline int x;
}

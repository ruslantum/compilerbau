int foo((4) x);

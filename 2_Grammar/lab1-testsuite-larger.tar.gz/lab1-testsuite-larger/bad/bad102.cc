int main () {
	1 + double;
}

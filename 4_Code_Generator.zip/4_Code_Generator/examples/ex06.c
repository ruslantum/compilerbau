int main() {

int i = 0;

if(++i > 0) {
return i;
} else {
return 0;
}

return 100;
}

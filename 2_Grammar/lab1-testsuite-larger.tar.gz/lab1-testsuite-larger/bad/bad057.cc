struct foo {
  int bar
} ;

int main () {
	int foo = x<int>::i;
}

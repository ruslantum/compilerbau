struct int x;

int main () {
	do {int x = 1; } struct foo { int y; }
}

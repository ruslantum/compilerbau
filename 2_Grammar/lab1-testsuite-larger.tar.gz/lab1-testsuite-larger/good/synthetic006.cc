inline a::b::c<d> banana() {}
a::b::c<d>::q banana2() {}
d banana_3(int x, a::b::c<d>::q);

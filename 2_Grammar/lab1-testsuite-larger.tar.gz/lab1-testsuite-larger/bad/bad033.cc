int foo() {
	while (5)
}

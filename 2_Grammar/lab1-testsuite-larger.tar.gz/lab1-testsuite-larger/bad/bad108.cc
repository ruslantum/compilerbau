int main () {
	inline x;
}

inline 1 foo() { }

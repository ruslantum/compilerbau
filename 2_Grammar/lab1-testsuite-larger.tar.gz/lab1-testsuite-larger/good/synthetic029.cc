int main() {
	int x = 1;
	do { if (x == 3) {} } while (x == 4);
}

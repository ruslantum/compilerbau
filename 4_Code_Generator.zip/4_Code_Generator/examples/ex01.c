int main () {
	 int i = 1;
	 return i;
}

void voidFun() {
	return;
}

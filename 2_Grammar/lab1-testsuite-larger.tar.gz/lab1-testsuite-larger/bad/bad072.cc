1 foo() { }

inline foo(double x) {
	return x + 9;
}

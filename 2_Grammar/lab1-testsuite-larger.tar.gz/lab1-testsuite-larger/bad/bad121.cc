int main() {
	return (int x = 3);
}

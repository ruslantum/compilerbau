int foo(int x, y int) {
	return x;
}

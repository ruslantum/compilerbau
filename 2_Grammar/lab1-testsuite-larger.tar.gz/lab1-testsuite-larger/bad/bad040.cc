int foo() {
	if (4) { } elseif { return 2; }
}

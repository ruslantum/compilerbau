int main () {
	(2+3) x;
}

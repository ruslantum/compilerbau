int main () {
	1 + bool;
}

int foo() {
	if (4)
}

struct bar {
	foo;
} ;

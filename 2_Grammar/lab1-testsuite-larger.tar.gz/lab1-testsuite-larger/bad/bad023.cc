struct bar {
	<foo> baz;
} ;

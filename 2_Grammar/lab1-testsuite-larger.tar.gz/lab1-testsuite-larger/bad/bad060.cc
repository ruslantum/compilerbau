int foo() {
else return 5;
}

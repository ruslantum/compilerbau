struct bar {
	int baz;
        foo;
} ;
